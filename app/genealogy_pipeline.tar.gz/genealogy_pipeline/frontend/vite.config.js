import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Proxy /dzi/* requests to the local tile server (m4_serve.sh starts it on 8001)
      // This avoids CORS issues during development.
      "/dzi": {
        target: "http://127.0.0.1:8001",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/dzi/, ""),
      },
    },
  },
});
