/**
 * ResultsList.jsx
 *
 * Renders the paginated list of Meilisearch search hits.
 *
 * Props
 * ─────
 *   results     {object|null}  Meilisearch search response (null = no search yet)
 *   activeHitId {string|null}  ID of the currently selected hit
 *   onSelect    {function}     Called with a hit object when the user clicks one
 */

import React from "react";
import ResultItem from "./ResultItem.jsx";

const styles = {
  container: {
    flex:       1,
    overflowY:  "auto",
    overflowX:  "hidden",
  },
  empty: {
    padding:    "2rem 1rem",
    textAlign:  "center",
    color:      "var(--text-muted)",
    fontSize:   "0.85rem",
  },
  summary: {
    padding:    "0.4rem 0.85rem",
    fontSize:   "0.72rem",
    color:      "var(--text-muted)",
    borderBottom: "1px solid rgba(255,255,255,0.05)",
    display:    "flex",
    justifyContent: "space-between",
  },
  error: {
    padding:    "1rem",
    color:      "#f44336",
    fontSize:   "0.82rem",
  },
};

export default function ResultsList({ results, activeHitId, onSelect, error }) {
  if (error) {
    return (
      <div style={styles.container}>
        <div style={styles.error}>
          ⚠ Could not reach Meilisearch.<br />
          Make sure it is running on <code>http://127.0.0.1:7700</code>.
        </div>
      </div>
    );
  }

  if (!results) {
    return (
      <div style={styles.container}>
        <div style={styles.empty}>Type to search …</div>
      </div>
    );
  }

  if (results.hits.length === 0) {
    return (
      <div style={styles.container}>
        <div style={styles.empty}>No results for "{results.query}"</div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.summary}>
        <span>~{results.estimatedTotalHits} hits</span>
        <span>{results.processingTimeMs} ms</span>
      </div>
      {results.hits.map((hit) => (
        <ResultItem
          key={hit.id}
          hit={hit}
          isActive={hit.id === activeHitId}
          onClick={() => onSelect(hit)}
        />
      ))}
    </div>
  );
}
