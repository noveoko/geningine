/**
 * ResultItem.jsx
 *
 * Renders a single Meilisearch search hit.
 *
 * Props
 * ─────
 *   hit       {object}   Meilisearch hit object.  Key fields:
 *                          hit.text              — raw OCR line text
 *                          hit._formatted.text   — same text with <mark> highlights
 *                          hit.page              — 1-indexed page number
 *                          hit.confidence        — average OCR confidence (0–1)
 *                          hit.source_file       — original filename
 *   isActive  {boolean}  True when this hit is currently shown in the viewer.
 *   onClick   {function} Called when the user clicks the item.
 */

import React from "react";

// Map confidence score to a colour for the badge
function confidenceColor(conf) {
  if (conf >= 0.85) return "#4caf50";
  if (conf >= 0.65) return "#ff9800";
  return "#f44336";
}

const styles = {
  item: (active) => ({
    padding:      "0.65rem 0.85rem",
    borderLeft:   `3px solid ${active ? "var(--accent)" : "transparent"}`,
    background:   active ? "rgba(233,69,96,0.08)" : "transparent",
    cursor:       "pointer",
    transition:   "background 0.12s, border-color 0.12s",
    borderBottom: "1px solid rgba(255,255,255,0.04)",
  }),
  text: {
    fontSize:   "0.88rem",
    lineHeight: 1.5,
    wordBreak:  "break-word",
  },
  meta: {
    display:    "flex",
    gap:        "0.5rem",
    marginTop:  "0.3rem",
    alignItems: "center",
    flexWrap:   "wrap",
  },
  chip: (color) => ({
    fontSize:     "0.68rem",
    background:   "rgba(255,255,255,0.07)",
    borderRadius: "4px",
    padding:      "1px 6px",
    color,
  }),
  filename: {
    fontSize:  "0.68rem",
    color:     "var(--text-muted)",
    overflow:  "hidden",
    textOverflow: "ellipsis",
    whiteSpace:   "nowrap",
    maxWidth:  "140px",
  },
};

export default function ResultItem({ hit, isActive, onClick }) {
  const confPct   = Math.round((hit.confidence ?? 0) * 100);
  const confColor = confidenceColor(hit.confidence ?? 0);
  // Use the Meilisearch-highlighted version if available
  const htmlText  = hit._formatted?.text ?? hit.text;

  return (
    <div
      style={styles.item(isActive)}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && onClick()}
      onMouseEnter={(e) => {
        if (!isActive) e.currentTarget.style.background = "rgba(255,255,255,0.04)";
      }}
      onMouseLeave={(e) => {
        if (!isActive) e.currentTarget.style.background = "transparent";
      }}
    >
      {/* Highlighted OCR text */}
      <div
        style={styles.text}
        dangerouslySetInnerHTML={{ __html: htmlText }}
      />

      {/* Metadata chips */}
      <div style={styles.meta}>
        <span style={styles.chip("var(--text-muted)")}>p. {hit.page}</span>
        <span style={styles.chip(confColor)}>conf {confPct}%</span>
        <span style={styles.filename} title={hit.source_file}>
          {hit.source_file}
        </span>
      </div>
    </div>
  );
}
