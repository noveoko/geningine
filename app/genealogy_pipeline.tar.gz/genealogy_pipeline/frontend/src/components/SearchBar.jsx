/**
 * SearchBar.jsx
 *
 * Instant-search input wired to Meilisearch.
 *
 * Props
 * ─────
 *   onResults  {function}  Called with the full Meilisearch response object
 *                          every time the query changes (debounced 300 ms).
 *   onError    {function}  Called with an Error object if the search fails.
 */

import React, { useCallback, useEffect, useRef, useState } from "react";
import { search } from "../searchClient.js";

const styles = {
  wrapper: {
    padding: "1rem",
    background: "var(--surface)",
    borderBottom: "1px solid var(--surface2)",
  },
  label: {
    display: "block",
    fontSize: "0.7rem",
    letterSpacing: "0.08em",
    textTransform: "uppercase",
    color: "var(--text-muted)",
    marginBottom: "0.4rem",
  },
  row: {
    display: "flex",
    gap: "0.5rem",
    alignItems: "center",
  },
  input: {
    flex: 1,
    background: "var(--bg)",
    border: "1px solid var(--surface2)",
    borderRadius: "var(--radius)",
    color: "var(--text)",
    fontSize: "0.95rem",
    padding: "0.55rem 0.75rem",
    outline: "none",
    transition: "border-color 0.15s",
  },
  badge: {
    fontSize: "0.72rem",
    color: "var(--text-muted)",
    whiteSpace: "nowrap",
  },
};

export default function SearchBar({ onResults, onError }) {
  const [query, setQuery]         = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const debounceRef               = useRef(null);

  // Debounced search: waits 300 ms after the user stops typing.
  const runSearch = useCallback(async (q) => {
    if (!q.trim()) {
      onResults(null);
      return;
    }
    setIsLoading(true);
    try {
      const res = await search(q);
      onResults(res);
    } catch (err) {
      onError?.(err);
    } finally {
      setIsLoading(false);
    }
  }, [onResults, onError]);

  useEffect(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runSearch(query), 300);
    return () => clearTimeout(debounceRef.current);
  }, [query, runSearch]);

  return (
    <div style={styles.wrapper}>
      <label htmlFor="search-input" style={styles.label}>
        Search genealogy records
      </label>
      <div style={styles.row}>
        <input
          id="search-input"
          style={styles.input}
          type="search"
          placeholder="e.g. Kowalski Jan 1897 …"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoComplete="off"
          spellCheck={false}
          onFocus={(e) => (e.target.style.borderColor = "var(--accent)")}
          onBlur={(e)  => (e.target.style.borderColor = "var(--surface2)")}
        />
        {isLoading && <span style={styles.badge}>searching …</span>}
      </div>
    </div>
  );
}
