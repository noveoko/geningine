/**
 * OpenSeadragonViewer.jsx
 *
 * Wraps an OpenSeadragon viewer instance in a React component.
 *
 * Props
 * ─────
 *   dziUrl   {string|null}  URL of the .dzi descriptor to load.
 *   hit      {object|null}  Current search hit from Meilisearch.
 *                           When set, the viewer opens the hit's page,
 *                           draws a highlight overlay, and pans to the region.
 *
 * Bounding box coordinate system
 * ───────────────────────────────
 * OpenSeadragon (OSD) uses a viewport coordinate system where the image width = 1.0.
 * The image height scales proportionally to H/W.
 *
 * The `hit.bbox` field from Meilisearch already uses this system (both x and y
 * are divided by the image width in Module 3).  We can therefore pass the bbox
 * values directly to new OpenSeadragon.Rect() without any further conversion.
 *
 * If you were to accidentally use pixel coordinates, OSD would position the
 * overlay thousands of viewport units away from the visible area.
 *
 * Overlay lifecycle
 * ─────────────────
 *   1. User clicks a search result → `hit` prop changes.
 *   2. useEffect detects change → clears old overlays.
 *   3. If the page is different → viewer.open(newDziUrl) is called.
 *   4. On the "open" event → drawHighlight(hit.bbox) + panToRegion(hit.bbox).
 *   5. If the page is the same → skip open(), draw + pan immediately.
 */

import React, { useEffect, useRef } from "react";
import OpenSeadragon from "openseadragon";

// ── Styles ───────────────────────────────────────────────────────────────────
const styles = {
  container: {
    width: "100%",
    height: "100%",
    background: "#0a0a0a",
    position: "relative",
  },
  placeholder: {
    position: "absolute",
    inset: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#8892a4",
    fontSize: "0.9rem",
    flexDirection: "column",
    gap: "0.5rem",
  },
};

// ── Component ─────────────────────────────────────────────────────────────────
export default function OpenSeadragonViewer({ dziUrl, hit }) {
  const containerRef = useRef(null);
  const viewerRef    = useRef(null);   // OSD viewer instance
  const currentPage  = useRef(null);   // currently loaded (doc_id, page) pair

  // ── Initialise OSD once ──────────────────────────────────────────────────
  useEffect(() => {
    if (!containerRef.current) return;

    viewerRef.current = OpenSeadragon({
      element:       containerRef.current,
      prefixUrl:     "https://cdn.jsdelivr.net/npm/openseadragon@5.0/build/openseadragon/images/",
      showNavigator: true,
      navigatorPosition:   "BOTTOM_RIGHT",
      navigatorSizeRatio:  0.18,
      showNavigationControl: true,
      minZoomLevel:  0.5,
      maxZoomLevel:  20,
      // Disable click-to-zoom so clicks in the results list don't fight the viewer
      gestureSettingsMouse: { clickToZoom: false },
      animationTime: 0.5,
      blendTime: 0.1,
    });

    return () => {
      viewerRef.current?.destroy();
      viewerRef.current = null;
    };
  }, []); // run once

  // ── React to new hits ─────────────────────────────────────────────────────
  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewer || !hit) return;

    const pageKey = `${hit.doc_id}_p${String(hit.page).padStart(3, "0")}`;
    const newDzi  = `/dzi/${pageKey}.dzi`;

    // Always clear old overlays
    viewer.clearOverlays();

    const afterOpen = () => {
      drawHighlight(viewer, hit.bbox);
      panToRegion(viewer, hit.bbox);
      currentPage.current = pageKey;
    };

    if (currentPage.current === pageKey && viewer.isOpen()) {
      // Same page already loaded — skip the open(), just overlay
      afterOpen();
    } else {
      viewer.addOnceHandler("open", afterOpen);
      viewer.open(newDzi);
    }
  }, [hit]);

  return (
    <div style={styles.container}>
      {!hit && (
        <div style={styles.placeholder}>
          <span style={{ fontSize: "2rem" }}>🔍</span>
          <span>Search for a name or phrase to view a scan</span>
        </div>
      )}
      {/* OSD mounts into this div */}
      <div ref={containerRef} style={{ width: "100%", height: "100%" }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Overlay helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * drawHighlight — place a semi-transparent yellow box over a search hit.
 *
 * bbox = [x0, y0, x1, y1] in OSD viewport coordinates.
 *
 * new OpenSeadragon.Rect(x, y, width, height) constructs the rectangle in
 * viewport space.  viewer.addOverlay() handles all pan/zoom transforms
 * automatically — we never need to reposition the overlay manually.
 */
function drawHighlight(viewer, bbox) {
  const [x0, y0, x1, y1] = bbox;

  const el = document.createElement("div");
  el.className = "search-highlight";

  viewer.addOverlay({
    element:  el,
    location: new OpenSeadragon.Rect(x0, y0, x1 - x0, y1 - y0),
  });
}

/**
 * panToRegion — smooth-pan + zoom so the hit is centred with padding.
 *
 * We add 20% padding on each side so users can see surrounding context.
 * viewer.viewport.fitBounds() handles the animation automatically.
 */
function panToRegion(viewer, bbox) {
  const [x0, y0, x1, y1] = bbox;
  const padX = (x1 - x0) * 0.20;
  const padY = (y1 - y0) * 0.20;

  const region = new OpenSeadragon.Rect(
    x0 - padX,
    y0 - padY,
    (x1 - x0) + 2 * padX,
    (y1 - y0) + 2 * padY,
  );

  viewer.viewport.fitBounds(region, /* immediately= */ false);
}
