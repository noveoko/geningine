/**
 * App.jsx — Root component
 *
 * Layout
 * ──────
 *   ┌─────────────────────────────────────────────────────────┐
 *   │  Header                                                 │
 *   ├──────────────┬──────────────────────────────────────────┤
 *   │  SearchBar   │                                          │
 *   │  ──────────  │         OpenSeadragon viewer             │
 *   │  ResultsList │                                          │
 *   └──────────────┴──────────────────────────────────────────┘
 *
 * State
 * ─────
 *   results      Meilisearch search response object
 *   activeHit    Currently selected hit (drives viewer + result highlight)
 *   searchError  Any error thrown by the Meilisearch client
 *
 * Data flow
 * ─────────
 *   1. User types in SearchBar
 *   2. SearchBar debounces → calls Meilisearch → returns results
 *   3. App stores results in state → ResultsList renders items
 *   4. User clicks ResultItem → App stores hit as activeHit
 *   5. OpenSeadragonViewer receives hit → loads DZI + draws overlay + pans
 */

import React, { useState, useCallback } from "react";
import SearchBar             from "./components/SearchBar.jsx";
import ResultsList           from "./components/ResultsList.jsx";
import OpenSeadragonViewer   from "./components/OpenSeadragonViewer.jsx";

// ── Layout styles ────────────────────────────────────────────────────────────
const styles = {
  root: {
    display:       "flex",
    flexDirection: "column",
    height:        "100dvh",
    overflow:      "hidden",
  },
  header: {
    background:   "var(--surface)",
    borderBottom: "1px solid var(--surface2)",
    padding:      "0.6rem 1rem",
    display:      "flex",
    alignItems:   "center",
    gap:          "0.75rem",
    flexShrink:   0,
  },
  logo: {
    fontSize:     "1.1rem",
    fontWeight:   700,
    letterSpacing: "-0.02em",
    color:        "var(--text)",
  },
  logoAccent: {
    color: "var(--accent)",
  },
  tagline: {
    fontSize:  "0.73rem",
    color:     "var(--text-muted)",
  },
  body: {
    display:  "flex",
    flex:     1,
    overflow: "hidden",
  },
  sidebar: {
    width:         "340px",
    minWidth:      "280px",
    maxWidth:      "420px",
    display:       "flex",
    flexDirection: "column",
    borderRight:   "1px solid var(--surface2)",
    background:    "var(--surface)",
    overflow:      "hidden",
  },
  viewer: {
    flex:     1,
    overflow: "hidden",
  },
};

export default function App() {
  const [results,     setResults]     = useState(null);
  const [activeHit,   setActiveHit]   = useState(null);
  const [searchError, setSearchError] = useState(null);

  const handleResults = useCallback((res) => {
    setResults(res);
    setSearchError(null);
    // If the active hit is no longer in the result set, deselect it
    if (activeHit && res && !res.hits.find((h) => h.id === activeHit.id)) {
      setActiveHit(null);
    }
  }, [activeHit]);

  const handleError = useCallback((err) => {
    console.error("Search error:", err);
    setSearchError(err);
  }, []);

  const handleSelect = useCallback((hit) => {
    setActiveHit(hit);
  }, []);

  return (
    <div style={styles.root}>
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <header style={styles.header}>
        <div>
          <div style={styles.logo}>
            Genealogy<span style={styles.logoAccent}>OCR</span>
          </div>
          <div style={styles.tagline}>
            Optical character recognition · historical records search
          </div>
        </div>
      </header>

      {/* ── Main body ──────────────────────────────────────────────────── */}
      <div style={styles.body}>
        {/* Left sidebar: search + results */}
        <aside style={styles.sidebar}>
          <SearchBar onResults={handleResults} onError={handleError} />
          <ResultsList
            results={results}
            activeHitId={activeHit?.id}
            onSelect={handleSelect}
            error={searchError}
          />
        </aside>

        {/* Right: deep zoom viewer */}
        <main style={styles.viewer}>
          <OpenSeadragonViewer hit={activeHit} />
        </main>
      </div>
    </div>
  );
}
