/**
 * searchClient.js
 *
 * Creates and exports a singleton Meilisearch client + search helper.
 *
 * The index name and host URL must match what Module 3 used when uploading.
 */

import { MeiliSearch } from "meilisearch";

const MS_HOST  = import.meta.env.VITE_MEILISEARCH_URL  || "http://127.0.0.1:7700";
const MS_KEY   = import.meta.env.VITE_MEILISEARCH_KEY  || "";
const INDEX    = import.meta.env.VITE_MEILISEARCH_IDX  || "genealogy_pages";

export const client = new MeiliSearch({ host: MS_HOST, apiKey: MS_KEY || undefined });
export const index  = client.index(INDEX);

/**
 * search(query, options) → Meilisearch search response
 *
 * Highlighting: wraps matched terms in <mark>…</mark> tags.
 * Filter:       only return hits with confidence > 0.5 (reduces noise from
 *               very uncertain OCR lines).
 *
 * @param {string} query
 * @param {object} opts   - override any Meilisearch search parameters
 */
export async function search(query, opts = {}) {
  return index.search(query, {
    attributesToHighlight: ["text"],
    highlightPreTag:  "<mark>",
    highlightPostTag: "</mark>",
    limit:  20,
    offset: 0,
    filter: ["confidence > 0.5"],
    ...opts,
  });
}
