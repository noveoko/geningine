"""
utils.py — shared helpers for the Genealogy OCR Pipeline.

Provides:
  - load_config()        read config.yaml relative to project root
  - get_doc_id()         deterministic 12-char SHA-256 hash of a filename
  - append_manifest()    atomic append to a _manifest.jsonl file
  - read_manifest()      iterate entries from a manifest
  - already_processed()  check if a doc_id+page combo is in a manifest
  - chunked()            split a list into batches
  - setup_logging()      consistent logging configuration
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator, Iterable

import yaml

# ─── Thread-safe manifest lock ────────────────────────────────────────────────
_MANIFEST_LOCK = threading.Lock()


# ─── Config ───────────────────────────────────────────────────────────────────

def find_project_root() -> Path:
    """Walk up from this file until we find config.yaml."""
    here = Path(__file__).resolve().parent
    for candidate in [here, here.parent, here.parent.parent]:
        if (candidate / "config.yaml").exists():
            return candidate
    raise FileNotFoundError("config.yaml not found. Run from project root.")


def load_config(path: str | Path | None = None) -> dict:
    """Load config.yaml.  If *path* is None, auto-discover from project root."""
    if path is None:
        root = find_project_root()
        path = root / "config.yaml"
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ─── Document ID ──────────────────────────────────────────────────────────────

def get_doc_id(original_filename: str) -> str:
    """
    Return a 12-character deterministic ID for a source file.

    Derived from the first 12 hex characters of the SHA-256 hash of the
    original filename (stem only, lower-cased).  This means the same source
    file always maps to the same doc_id regardless of the directory it lives in.

    Example
    -------
    >>> get_doc_id("parish_register_1897.pdf")
    'a3f8b1c2d4e5'   # illustrative — actual value depends on hash
    """
    stem = Path(original_filename).name  # keep extension to disambiguate
    digest = hashlib.sha256(stem.encode("utf-8")).hexdigest()
    return digest[:12]


# ─── Manifest helpers ─────────────────────────────────────────────────────────

def manifest_path(folder: str | Path) -> Path:
    return Path(folder) / "_manifest.jsonl"


def append_manifest(folder: str | Path, entry: dict[str, Any]) -> None:
    """
    Atomically append *entry* as a single JSON line to the folder's manifest.

    Thread-safe: uses a module-level lock so multiple worker threads can call
    this without interleaving partial writes.
    """
    if "ts" not in entry:
        entry["ts"] = datetime.now(timezone.utc).isoformat(timespec="seconds")

    line = json.dumps(entry, ensure_ascii=False) + "\n"
    mpath = manifest_path(folder)

    with _MANIFEST_LOCK:
        with open(mpath, "a", encoding="utf-8") as f:
            f.write(line)


def read_manifest(folder: str | Path) -> Generator[dict, None, None]:
    """Yield each JSON object from a folder's _manifest.jsonl (skip blank lines)."""
    mpath = manifest_path(folder)
    if not mpath.exists():
        return
    with open(mpath, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def already_processed(folder: str | Path, doc_id: str, page: int) -> bool:
    """
    Return True if a (doc_id, page) pair already has a 'ready' entry in
    the manifest, so we can skip re-processing (idempotent runs).
    """
    for entry in read_manifest(folder):
        if entry.get("doc_id") == doc_id and entry.get("page") == page:
            return True
    return False


def processed_set(folder: str | Path) -> set[tuple[str, int]]:
    """
    Return a set of (doc_id, page) tuples already recorded in the manifest.
    Much faster than calling already_processed() in a loop for large manifests.
    """
    seen: set[tuple[str, int]] = set()
    for entry in read_manifest(folder):
        if "doc_id" in entry and "page" in entry:
            seen.add((entry["doc_id"], entry["page"]))
    return seen


# ─── Batching ─────────────────────────────────────────────────────────────────

def chunked(iterable: Iterable, size: int) -> Generator[list, None, None]:
    """Yield successive fixed-size chunks from *iterable*."""
    buf: list = []
    for item in iterable:
        buf.append(item)
        if len(buf) == size:
            yield buf
            buf = []
    if buf:
        yield buf


# ─── Page filename helpers ────────────────────────────────────────────────────

def page_stem(doc_id: str, page: int) -> str:
    """Return the filename stem for a given doc_id + page, e.g. 'a3f8b1c2d4e5_p001'."""
    return f"{doc_id}_p{page:03d}"


# ─── Logging ──────────────────────────────────────────────────────────────────

def setup_logging(level: int = logging.INFO, module_name: str = "pipeline") -> logging.Logger:
    """Configure and return a logger with a timestamp prefix."""
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    return logging.getLogger(module_name)
