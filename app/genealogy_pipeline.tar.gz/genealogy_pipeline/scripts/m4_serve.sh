#!/usr/bin/env bash
# m4_serve.sh — Module 4: Start all services needed for the frontend
#
# Services started
# ────────────────
#   1. Meilisearch       http://127.0.0.1:7700
#   2. DZI tile server   http://127.0.0.1:8001  (serves data/output_dzi/)
#   3. React dev server  http://127.0.0.1:5173  (Vite, inside frontend/)
#
# Usage
# ─────
#   bash scripts/m4_serve.sh            # start all services
#   bash scripts/m4_serve.sh --prod     # production mode (nginx hints printed)
#
# All background processes are tracked and killed on Ctrl-C.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
DZI_DIR="$PROJECT_ROOT/data/output_dzi"
FRONTEND_DIR="$PROJECT_ROOT/frontend"

MEILI_PORT=7700
TILE_PORT=8001
VITE_PORT=5173

PIDS=()

cleanup() {
    echo ""
    echo "Stopping all services …"
    for pid in "${PIDS[@]}"; do
        kill "$pid" 2>/dev/null || true
    done
    exit 0
}
trap cleanup SIGINT SIGTERM

# ── 1. Meilisearch ────────────────────────────────────────────────────────────
if command -v meilisearch &>/dev/null; then
    echo "▶  Starting Meilisearch on port $MEILI_PORT …"
    meilisearch --master-key="" --http-addr="127.0.0.1:$MEILI_PORT" &
    PIDS+=($!)
else
    echo "⚠  meilisearch binary not found."
    echo "   Install: curl -L https://install.meilisearch.com | sh"
fi

# ── 2. DZI tile server ────────────────────────────────────────────────────────
echo "▶  Starting DZI tile server on port $TILE_PORT …"
mkdir -p "$DZI_DIR"
(cd "$DZI_DIR" && python3 -m http.server $TILE_PORT --bind 127.0.0.1) &
PIDS+=($!)

# ── 3. React / Vite dev server ────────────────────────────────────────────────
if [ -d "$FRONTEND_DIR" ] && [ -f "$FRONTEND_DIR/package.json" ]; then
    echo "▶  Starting React dev server on port $VITE_PORT …"
    (cd "$FRONTEND_DIR" && npm run dev -- --port $VITE_PORT) &
    PIDS+=($!)
else
    echo "⚠  Frontend not found at $FRONTEND_DIR"
    echo "   Run: cd frontend && npm install && npm run dev"
fi

echo ""
echo "Services running:"
echo "  Meilisearch  →  http://127.0.0.1:$MEILI_PORT"
echo "  DZI tiles    →  http://127.0.0.1:$TILE_PORT"
echo "  Frontend     →  http://127.0.0.1:$VITE_PORT"
echo ""
echo "Press Ctrl-C to stop all services."

# Wait for all background processes
wait
